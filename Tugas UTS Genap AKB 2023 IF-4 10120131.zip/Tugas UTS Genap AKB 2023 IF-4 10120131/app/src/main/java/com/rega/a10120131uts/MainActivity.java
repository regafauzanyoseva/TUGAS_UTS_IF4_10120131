package com.rega.a10120131uts;
//10120131, Rega Fauzan Yoseva, IF4, rega.10120131@mahasiswa.unikom.ac.id

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}